import UIKit

var myAge = 32

//<, >, ==, !=
//AND &&
//OR ||

if myAge < 30 {
    print("30-")
} else if myAge > 30 && myAge < 40 {
    print("30s")
} else {
    print("40+")
}
